
            // Функция для инициализации пролистываемого слайдера
            function initBooksSlider(sliderId, arrowLeftId, arrowRightId) {
                const slider = document.getElementById(sliderId);
                const arrowLeft = document.querySelector(`#${sliderId} ~ .slider-arrow-left`);
                const arrowRight = document.querySelector(`#${sliderId} ~ .slider-arrow-right`);

                if (!slider || !arrowLeft || !arrowRight) {
                    console.error(`Не удалось найти элементы для слайдера ${sliderId}`);
                    return;
                }

                // Получаем ширину одного слайда (карточки)
                const slideWidth = slider.firstElementChild ? slider.firstElementChild.offsetWidth : 200;

                // Функция для прокрутки влево
                arrowLeft.addEventListener('click', () => {
                    slider.scrollBy({
                        left: -slideWidth,
                        behavior: 'smooth'
                    });
                });

                // Функция для прокрутки вправо
                arrowRight.addEventListener('click', () => {
                    slider.scrollBy({
                        left: slideWidth,
                        behavior: 'smooth'
                    });
                });

                // Также можно добавить возможность прокрутки колесиком мыши
                slider.addEventListener('wheel', (e) => {
                    e.preventDefault();
                    slider.scrollBy({
                        left: e.deltaY > 0 ? slideWidth : -slideWidth,
                        behavior: 'smooth'
                    });
                }, { passive: false });

                // Для мобильных устройств - свайпы
                let startX = 0;
                slider.addEventListener('touchstart', (e) => {
                    startX = e.touches[0].clientX;
                });

                slider.addEventListener('touchmove', (e) => {
                    e.preventDefault();
                    const moveX = e.touches[0].clientX;
                    const diff = startX - moveX;
                    if (Math.abs(diff) > 30) { // Минимальное движение для срабатывания
                        slider.scrollBy({
                            left: diff,
                            behavior: 'auto' // Для свайпов лучше использовать 'auto'
                        });
                        startX = moveX;
                    }
                });
            }

            // Инициализация всех слайдеров при загрузке страницы
            document.addEventListener('DOMContentLoaded', () => {
                // Инициализируем слайдер "Рекомендации для вас"
                initBooksSlider('recommendationsSlider', 'recommendationsSliderArrowLeft', 'recommendationsSliderArrowRight');

                // Инициализируем слайдер "Новинки"
                initBooksSlider('newReleasesSlider', 'newReleasesSliderArrowLeft', 'newReleasesSliderArrowRight');

                // Инициализируем слайдер "Популярное"
                initBooksSlider('popularSlider', 'popularSliderArrowLeft', 'popularSliderArrowRight');

                // Инициализируем слайдер "Страшилки"
                initBooksSlider('horrorSlider', 'horrorSliderArrowLeft', 'horrorSliderArrowRight');

                // Инициализируем слайдер "Плейлисты по авторам"
                initBooksSlider('authorPlaylistsSlider', 'authorPlaylistsSliderArrowLeft', 'authorPlaylistsSliderArrowRight');
            });

            // Функция для перехода на главную страницу (при клике на логотип)
            function goToMain2() {
                // Здесь можно реализовать переход на главную страницу
                console.log("Переход на главную страницу");
                // window.location.href = "/"; // Раскомментируйте, если нужно перенаправление
            }

            // Функция для показа/скрытия выпадающего каталога
            document.addEventListener('DOMContentLoaded', () => {
                const catalogBtn = document.getElementById('catalogBtn');
                const catalogDropdown = document.getElementById('catalogDropdown');

                catalogBtn.addEventListener('click', () => {
                    catalogDropdown.classList.toggle('show');
                });

                // Закрытие каталога при клике вне его
                document.addEventListener('click', (event) => {
                    if (!catalogBtn.contains(event.target) && !catalogDropdown.contains(event.target)) {
                        catalogDropdown.classList.remove('show');
                    }
                });
            });

            // Обработка событий для карточек книг (переход на страницу книги)
            document.addEventListener('DOMContentLoaded', () => {
                const bookCards = document.querySelectorAll('.book-card');
                bookCards.forEach(card => {
                    card.addEventListener('click', function() {
                        // Здесь можно добавить логику перехода на страницу конкретной книги
                        console.log('Карточка книги нажата:', this);
                        // Например: window.location.href = `/book/${bookId}`;
                    });
                });
            });

            // Обработчики для кнопок "ЕЩЁ" и заголовков разделов
            document.addEventListener('DOMContentLoaded', () => {
                // Добавляем обработчики для всех кнопок "ЕЩЁ" и ссылок в заголовках
                const moreLinks = document.querySelectorAll('.more-link, .section-link');
                moreLinks.forEach(link => {
                    link.addEventListener('click', function(e) {
                        e.preventDefault(); // Предотвращаем стандартное поведение ссылки
                        // Здесь можно добавить логику перехода на соответствующую страницу жанра/раздела
                        console.log('Нажата ссылка:', this.textContent, 'или кнопка ЕЩЁ');
                        // Например: window.location.href = `/genre/${genreSlug}`;
                    });
                });
            });

            // Скрипт для слайдера в hero-секции (оставлен без изменений из исходного файла)
            // Получаем элементы слайдера
            const slider = document.querySelector('.slider');
            const prevButton = document.querySelector('.prev-button');
            const nextButton = document.querySelector('.next-button');
            const slides = Array.from(slider.querySelectorAll('img'));
            const slideCount = slides.length;
            let slideIndex = 0;
            let autoPlayInterval;

            // Устанавливаем обработчики событий для кнопок
            prevButton.addEventListener('click', showPreviousSlide);
            nextButton.addEventListener('click', showNextSlide);

            // Остановка автоплея при наведении мыши на слайдер
            slider.addEventListener('mouseenter', stopAutoPlay);
            slider.addEventListener('mouseleave', startAutoPlay);

            // Функция для показа предыдущего слайда
            function showPreviousSlide() {
                slideIndex = (slideIndex - 1 + slideCount) % slideCount;
                updateSlider();
                resetAutoPlay();
            }

            // Функция для показа следующего слайда
            function showNextSlide() {
                slideIndex = (slideIndex + 1) % slideCount;
                updateSlider();
                resetAutoPlay();
            }

            // Функция для обновления отображения слайдера
            function updateSlider() {
                // Используем transform для плавного перехода
                const offset = -slideIndex * 100;
                slider.style.transform = `translateX(${offset}%)`;
                // Обновляем видимость слайдов для accessibility
                slides.forEach((slide, index) => {
                    slide.style.opacity = index === slideIndex ? '1' : '0.7';
                    slide.setAttribute('aria-hidden', index !== slideIndex);
                });
            }

            // Функции для автоплея
            function startAutoPlay() {
                autoPlayInterval = setInterval(showNextSlide, 5000);
            }

            function stopAutoPlay() {
                clearInterval(autoPlayInterval);
            }

            function resetAutoPlay() {
                stopAutoPlay();
                startAutoPlay();
            }

            // Функция для перехода к конкретному слайду (для будущих индикаторов)
            function goToSlide(index) {
                slideIndex = index;
                updateSlider();
                resetAutoPlay();
            }

            // Инициализация слайдера
            function initSlider() {
                // Устанавливаем начальные стили для слайдера
                slider.style.display = 'flex';
                slider.style.transition = 'transform 0.5s ease-in-out';
                // Устанавливаем начальные стили для изображений
                slides.forEach((slide, index) => {
                    slide.style.flex = '0 0 100%';
                    slide.style.width = '100%';
                    slide.style.height = '100%';
                    slide.style.objectFit = 'cover';
                    slide.style.transition = 'opacity 0.3s ease';
                });
                // Первоначальное обновление
                updateSlider();
                // Запускаем автоплей
                startAutoPlay();
            }

            // Обработка клавиатурных событий
            document.addEventListener('keydown', (e) => {
                if (e.key === 'ArrowLeft') {
                    showPreviousSlide();
                } else if (e.key === 'ArrowRight') {
                    showNextSlide();
                }
            });

            // Функция для создания индикаторов слайдов
            function createIndicators() {
                const indicatorsContainer = document.createElement('div');
                indicatorsContainer.className = 'slider-indicators';
                for (let i = 0; i < slideCount; i++) {
                    const indicator = document.createElement('button');
                    indicator.className = 'indicator';
                    indicator.setAttribute('aria-label', `Перейти к слайду ${i + 1}`);
                    indicator.addEventListener('click', () => goToSlide(i));
                    indicatorsContainer.appendChild(indicator);
                }
                const sliderContainer = document.querySelector('.slider-container');
                sliderContainer.appendChild(indicatorsContainer);
                // Обновляем активный индикатор
                function updateIndicators() {
                    const indicators = indicatorsContainer.querySelectorAll('.indicator');
                    indicators.forEach((indicator, index) => {
                        indicator.classList.toggle('active', index === slideIndex);
                    });
                }
                // Добавляем вызов обновления индикаторов в updateSlider
                const originalUpdateSlider = updateSlider;
                updateSlider = function() {
                    originalUpdateSlider();
                    updateIndicators();
                };
            }

            // Дополнительные стили для индикаторов
            const indicatorStyles = `
                .slider-indicators {
                    position: absolute;
                    bottom: 20px;
                    left: 50%;
                    transform: translateX(-50%);
                    display: flex;
                    gap: 8px;
                    z-index: 10;
                }
                .indicator {
                    width: 12px;
                    height: 12px;
                    border-radius: 50%;
                    border: none;
                    background: rgba(255, 255, 255, 0.5);
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                .indicator:hover {
                    background: rgba(255, 255, 255, 0.8);
                }
                .indicator.active {
                    background: white;
                    width: 32px;
                    border-radius: 6px;
                }
            `;
            // Добавляем стили в head
            const styleSheet = document.createElement('style');
            styleSheet.textContent = indicatorStyles;
            document.head.appendChild(styleSheet);

            // Инициализация при загрузке DOM
            document.addEventListener('DOMContentLoaded', () => {
                initSlider();
                createIndicators();
            });

            // Обработка visibility change для оптимизации
            document.addEventListener('visibilitychange', () => {
                if (document.hidden) {
                    stopAutoPlay();
                } else {
                    startAutoPlay();
                }
            });

            // Функции для рекламных блоков
            document.addEventListener('DOMContentLoaded', () => {
                // Добавляем обработчики для рекламных блоков
                const adBlocks = document.querySelectorAll('.ad-block');
                adBlocks.forEach(block => {
                    block.addEventListener('click', function() {
                        // Здесь можно добавить логику перехода на рекламные страницы
                        console.log('Рекламный блок нажат:', this);
                    });
                });
                // Добавляем обработчики для карточек книг
                const bookCards = document.querySelectorAll('.book-card');
                bookCards.forEach(card => {
                    card.addEventListener('click', function() {
                        // Здесь можно добавить логику перехода на страницы книг
                        console.log('Карточка книги нажата:', this);
                    });
                });
                // Обработчик для кнопки Black Friday
                const bfBtn = document.querySelector('.bf-btn');
                if (bfBtn) {
                    bfBtn.addEventListener('click', () => {
                        console.log('Black Friday кнопка нажата');
                        // Здесь можно добавить логику перехода на страницу распродажи
                    });
                }
            });

            // Функция для плавной прокрутки к элементу
            function scrollToElement(elementId) {
                const element = document.getElementById(elementId);
                if (element) {
                    element.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }

            // Добавляем обработчики для навигации
            document.addEventListener('DOMContentLoaded', () => {
                const navLinks = document.querySelectorAll('.nav-menu a');
                navLinks.forEach(link => {
                    link.addEventListener('click', function(e) {
                        // Удаляем класс active у всех ссылок
                        navLinks.forEach(l => l.classList.remove('active'));
                        // Добавляем класс active к текущей ссылке
                        this.classList.add('active');
                    });
                });
            });

            // Оптимизация производительности - debounce функция
            function debounce(func, wait) {
                let timeout;
                return function executedFunction(...args) {
                    const later = () => {
                        clearTimeout(timeout);
                        func(...args);
                    };
                    clearTimeout(timeout);
                    timeout = setTimeout(later, wait);
                };
            }

            // Оптимизация resize событий
            const handleResize = debounce(() => {
                // Логика для адаптации слайдера при изменении размера окна
                updateSlider();
            }, 250);
            window.addEventListener('resize', handleResize);

            // Экспорт функций для возможного использования извне
            window.sliderAPI = {
                nextSlide: showNextSlide,
                prevSlide: showPreviousSlide,
                goToSlide: goToSlide,
                stopAutoPlay: stopAutoPlay,
                startAutoPlay: startAutoPlay
            };
